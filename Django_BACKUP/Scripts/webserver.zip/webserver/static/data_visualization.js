//初始化基本變數
const COLORS = [
    '#4dc9f6',
    '#f67019',
    '#f53794',
    '#537bc4',
    '#acc236',
    '#166a8f',
    '#00a950',
    '#58595b',
    '#8549ba'
];

const CHART_COLORS = {
    red: 'rgb(255, 99, 132)',
    orange: 'rgb(255, 159, 64)',
    yellow: 'rgb(255, 205, 86)',
    green: 'rgb(75, 192, 192)',
    blue: 'rgb(54, 162, 235)',
    purple: 'rgb(153, 102, 255)',
    grey: 'rgb(201, 203, 207)'
};

const NAMED_COLORS = [
    CHART_COLORS.red,
    CHART_COLORS.orange,
    CHART_COLORS.yellow,
    CHART_COLORS.green,
    CHART_COLORS.blue,
    CHART_COLORS.purple,
    CHART_COLORS.grey,
];

//Overall那頁的第一張圖
const stack_bar_chart=(streaming_datas)=>{

    //拆解傳進來的變數
    let data_length=streaming_datas.length;
    let streaming_names=streaming_datas[0];
    let streaming_times=streaming_datas[1];
    let streaming_likes=streaming_datas[2];
    let streaming_comments=streaming_datas[3];
    let streaming_shares=streaming_datas[4];
    let streaming_order_amounts=streaming_datas[5];
    let streaming_views=streaming_datas[6];

    // <block:setup:1>
    const DATA_COUNT = data_length;
    const NUMBER_CFG = { count: DATA_COUNT, min: -100, max: 100 };

    const labels = streaming_names;

    const stack_bar_chart_config = {
        type: 'bar',
        data: {
            labels: streaming_times, // responsible for how many bars are gonna show on the chart
            //邊界寬度
            borderWidth: 1,
            datasets: [{
                label: '按讚數',
                data: streaming_likes,
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgba(255,99,132,1)',
                borderWidth: 1,
            }, {
                label: '留言數',
                data: streaming_comments,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
            }, {
                label: '分享數',
                data: streaming_shares,
                backgroundColor: 'rgba(255, 206, 86, 0.2)',
                borderColor: 'rgba(255, 206, 86, 1)',
                borderWidth: 1,
            }, {
                label: '訂單總數',
                data: streaming_order_amounts,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1,
            }, {
                label: '觀看數',
                data: streaming_views,
                backgroundColor: 'rgba(153, 102, 255, 0.2)',
                borderColor: 'rgba(153, 102, 255, 1)',
                borderWidth: 1,
            }]
        },
        options: {
            plugins: {
                title: {
                    display: true,
                    text: '各日期直播場次互動數圖'
                },
                legend: {
                    position: 'top',
                },
            },
            responsive: true,
            legend: {
                position: 'right' // place legend on the right side of chart
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: '日期',
                        color: '#911',
                        font: {
                            family: 'Comic Sans MS',
                            size: 20,
                            weight: 'bold',
                            lineHeight: 1.2,
                        },
                        padding: { top: 20, left: 0, right: 0, bottom: 0 }
                    },
                    stacked:true,
                },

                y: {
                    display: true,
                    title: {
                        display: true,
                        text: '數量',
                        color: '#191',
                        font: {
                            family: 'Comic Sans MS',
                            size: 20,
                            weight: 'bold',
                            lineHeight: 1.2,
                        },
                        padding: { top: 30, left: 0, right: 0, bottom: 0 }
                    },
                    stacked:true,
                }
            },
        }
    };
    return stack_bar_chart_config;
}

//數場直播下的每標狀況
const bid_step_chart_data=()=>{

    // </block:actions>
    const bid_step_chart_data = {
        labels: ['第一標', '第二標', '第三標', '第四標', '第五標', '第六標'],
        datasets: [
            {
                label: '8/23',
                data: [25, 50, 62, 45, 39, 33],
                borderColor: 'rgba(255,99,132,1)',
                fill: false,
                stepped: true,
            },
            {
                label: '8/24',
                data: [15, 35, 47, 52, 67, 58],
                borderColor: 'rgba(54, 162, 235, 1)',
                fill: false,
                stepped: true,
            },
            {
                label: '8/25',
                data: [21, 56, 89, 64, 53, 12],
                borderColor: 'rgba(255, 206, 86, 1)',
                fill: false,
                stepped: true,
            },
            {
                label: '8/26',
                data: [8, 18, 34, 44, 48, 52],
                borderColor: 'rgba(75, 192, 192, 1)',
                fill: false,
                stepped: true,
            },
            {
                label: '8/27',
                data: [21, 35, 41, 49, 58, 56],
                borderColor: 'rgba(153, 102, 255, 1)',
                fill: false,
                stepped: true,
            },
            {
                label: '8/28',
                data: [23, 56, 84, 110, 96, 65],
                borderColor: 'rgba(255, 159, 64,1)',
                fill: false,
                stepped: true,
            },
            {
                label: '8/29',
                data: [32, 45, 52, 35, 67, 98],
                borderColor: 'rgb(201, 203, 207)',
                fill: false,
                stepped: true,
            }
        ]
    };
    // </block:setup>
}


const orders_bar_data=()=>{

    const orders_bar_data = {
        labels: ['8/23', '8/24', '8/25', '8/26', '8/27', '8/28', '8/29'],
        datasets: [{
            type: 'bar',
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(201, 203, 207,0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
                'rgba(201, 203, 207,1)'
            ],
            borderWidth: 1,
            label: '總下單量',
            data: [2420, 2103, 1780, 2458, 1970, 1789, 3221]
        }, {
            type: 'line',
            label: '銷售業績(萬)',
            data: [80, 49, 72, 89, 92, 110, 106]
        }]
    };
}

const orders_bar_config=()=>{

    const orders_bar_config = {
        display: true,
        type: 'bar',
        data: orders_bar_data,
        options: {
            plugins: {
                title: {
                    display: true,
                    text: '各場次單據完成數量圖'
                },
                legend: {
                    position: 'top',
                },
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: '場次',
                        color: '#911',
                        font: {
                            family: 'Comic Sans MS',
                            size: 20,
                            weight: 'bold',
                            lineHeight: 1.2,
                        },
                        padding: { top: 20, left: 0, right: 0, bottom: 0 }
                    }
                },

                y: {
                    display: true,
                    title: {
                        display: true,
                        text: '單據完成數量',
                        color: '#191',
                        font: {
                            family: 'Comic Sans MS',
                            size: 20,
                            weight: 'bold',
                            lineHeight: 1.2,
                        },
                        padding: { top: 30, left: 0, right: 0, bottom: 0 }
                    },
                    //min: 0,
                    //max: 1,
                }
            },
            responsive: false,
        }
    };
}

const bid_step_chart_config=()=>{
    // <block:config:0>
    const bid_step_chart_config = {
        type: 'line',
        data: bid_step_chart_data,
        options: {
            responsive: true,
            interaction: {
                intersect: false,
                axis: 'x'
            },
            plugins: {
                title: {
                    display: true,
                    text: (ctx) => '各標下單數量圖',
                }
            }
        }
    };
    // </block:config>
}

const orders_line_chart_data=()=>{
    /**
    const orders_line_chart_data = {
        labels: [0,1,2,3,4,5],
        datasets: [
            {
                label: '各場次直播訂單完成數',
                data: [250, 284, 156, 268, 352, 132],
                borderColor: [
                    'rgba(255,99,132,1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                ],
                backgroundColor: CHART_COLORS.red
            },
        ]
    };
    **/
}

const orders_line_chart_config=()=>{

  /**
  const orders_line_chart_config = {
        type: 'line',
        data: orders_line_chart_data,
        options: {
            responsive: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: '各場次直播訂單完成數折線圖'
                }
            }
        },
  };
  **/
}

const payment_term_pie_chart=()=>{

    /**
    //drop proportion pie chart
    const payment_term_pie_data = {
        labels: ['貨到付款', '信用卡', '匯款轉帳', '超商代碼', '面交自取付款'],
        //labels: ['Red', 'Orange', 'Yellow', 'Green', 'Blue'],
        datasets: [
            {
                label: '棄單比例',
                data: [0.3, 0.3, 0.2, 0.1, 0.1],
                backgroundColor: Object.values(CHART_COLORS),
            },
        ]
    };
    // </block:setup>
    */
}

const payment_term_pie_config=()=>{

    /**
    // <block:config:0>
    const payment_term_pie_config = {
        display: true,
        type: 'pie',
        data: payment_term_pie_data,
        options: {
            plugins: {
                title: {
                    display: true,
                    text: '單場次付款方式比例圓餅圖'
                },
                legend: {
                    position: 'right',
                },
            },

            responsive: false,

        }
    };
    */
}

const payment_term_bar_chart=()=>{

    /**
    //payment term bar chart
    const payment_term_bar_data = {
        datasets: [
            {
                label: '信用卡',
                data: [{ x: '丟丟妹', y: 0.2 }, { x: '丟丟妹第二場', y: 0.7 }],
                backgroundColor: CHART_COLORS.green,
            },
            {
                label: '貨到付款',
                data: [{ x: '丟丟妹', y: 0.4 }, { x: '丟丟妹第二場', y: 0.5 }],
                backgroundColor: CHART_COLORS.red,
            },
        ]
    };
    */
}

const payment_term_bar_config=()=>{

    /**
    // <block:config:0>
    const payment_term_bar_config = {
        display: true,
        type: 'bar',
        data: payment_term_bar_data,
        options: {
            plugins: {
                title: {
                    display: true,
                    text: '各場次付款方式比例圖'
                },
                legend: {
                    position: 'top',
                },
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: '場次',
                        color: '#911',
                        font: {
                            family: 'Comic Sans MS',
                            size: 20,
                            weight: 'bold',
                            lineHeight: 1.2,
                        },
                        padding: { top: 20, left: 0, right: 0, bottom: 0 }
                    }
                },

                y: {
                    display: true,
                    title: {
                        display: true,
                        text: '比例',
                        color: '#191',
                        font: {
                            family: 'Comic Sans MS',
                            size: 20,
                            weight: 'bold',
                            lineHeight: 1.2,
                        },
                        padding: { top: 30, left: 0, right: 0, bottom: 0 }
                    },
                    min: 0,
                    max: 1,
                }
            },
            responsive: false,
        }
    };
    */
}

const drop_bar_data=()=>{

    /**
    //drop proportion bar chart
    const drop_bar_data = {
        datasets: [
            {
                label: '棄單比例',
                data: [{ x: '丟丟妹', y: 0.5 }, { x: '丟丟妹第二場', y: 0.2 }],
                backgroundColor: CHART_COLORS.green,
            },
            {
                label: '已完成比例',
                data: [{ x: '丟丟妹', y: 0.3 }, { x: '丟丟妹第二場', y: 0.5 }],
                backgroundColor: CHART_COLORS.red,
            },
        ]
    };
    // </block:setup>
    */
}

const drop_bar_config=()=>{

    /**
    // <block:config:0>
    const drop_bar_config = {
        display: true,
        type: 'bar',
        data: drop_bar_data,
        options: {
            plugins: {
                title: {
                    display: true,
                    text: '各場次棄單比例圖'
                },
                legend: {
                    position: 'top',
                },
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: '場次',
                        color: '#911',
                        font: {
                            family: 'Comic Sans MS',
                            size: 20,
                            weight: 'bold',
                            lineHeight: 1.2,
                        },
                        padding: { top: 20, left: 0, right: 0, bottom: 0 }
                    }
                },

                y: {
                    display: true,
                    title: {
                        display: true,
                        text: '比例',
                        color: '#191',
                        font: {
                            family: 'Comic Sans MS',
                            size: 20,
                            weight: 'bold',
                            lineHeight: 1.2,
                        },
                        padding: { top: 30, left: 0, right: 0, bottom: 0 }
                    },
                    min: 0,
                    max: 1,
                }
            },
            responsive: false,
        }
    };
    */
}

const drop_pie_data=()=>{
    /**
    //drop proportion pie chart
    const drop_pie_data = {
        labels: ['已下單', '已付款', '已完成', '棄單',],
        //labels: ['Red', 'Orange', 'Yellow', 'Green', 'Blue'],
        datasets: [
            {
                label: '棄單比例',
                data: [0.2, 0.3, 0.2, 0.3],
                backgroundColor: Object.values(CHART_COLORS),
            },
        ]
    };
    // </block:setup>
    */
}

const drop_pie_config=()=>{

    /**
    // <block:config:0>
    const drop_pie_config = {
        display: true,
        type: 'pie',
        data: drop_pie_data,
        options: {
            plugins: {
                title: {
                    display: true,
                    text: '單場次訂單狀況比例圓餅圖'
                },
                legend: {
                    position: 'right',
                },
            },

            responsive: false,

        }
    };
    */
}


const window_onload=(id,config)=>{

    console.log(id);
    console.log(config);

    window.onload=function(){
        var streaming_stack_bar_ctx = document.getElementById(id).getContext("2d");
        var streaming_stack_bar_chart = new Chart(streaming_stack_bar_ctx, config);
    }
}
/**
    // </block:config>
    window.onload = function () {

        var streaming_stack_bar_ctx = document.getElementById("streaming_stack_bar_chart").getContext("2d");
        var streaming_stack_bar_chart = new Chart(streaming_stack_bar_ctx, stack_bar_chart_config);

        var bid_step_chart_ctx = document.getElementById('bid_step_chart_chart').getContext('2d');
        var bid_step_chart_stacked = new Chart(bid_step_chart_ctx, bid_step_chart_config);

        var orders_bar_ctx = document.getElementById('orders_bar_chart').getContext('2d');
        var orders_bar_myChart = new Chart(orders_bar_ctx, orders_bar_config);

        var payment_term_pie_ctx = document.getElementById('payment_term_pie_chart').getContext('2d');
        window.payment_term_pie_chart = new Chart(payment_term_pie_ctx, payment_term_pie_config);

        var payment_term_bar_ctx = document.getElementById('payment_term_bar_chart').getContext('2d');
        window.payment_term_bar_chart = new Chart(payment_term_bar_ctx, payment_term_bar_config);

        var drop_bar_ctx = document.getElementById('drop_chart').getContext('2d');
        window.my_drop_chart = new Chart(drop_bar_ctx, drop_bar_config);

        var drop_pie_ctx = document.getElementById('drop_pie_chart').getContext('2d');
        window.myDropChart = new Chart(drop_pie_ctx, drop_pie_config);


    };
**/