var header = '<div class="wrapper site-header-wrapper clear">\
                <h1 class="site-logo">\
                    <img src="https://s3.ap-northeast-2.amazonaws.com/jambolive.tv/static/console2/img/common/logo.png" alt="" title="">\
                </h1>\
                <h2 class="page-title theme">策 略 小 助 手</h2>\
        <nav>\
          <ul class="owner_head-tool float-l align-c">\
            <li>\
              <a href="/console/live/" target="_blank" class="btn-reg btn-nr f-line f-min">直播小幫手</a>\
            </li>\
            <li>\
              <a href="/console/order/" target="_blank" class="btn-reg btn-nr f-line f-min">訂單小幫手</a>\
            </li>\
            <li>\
              <a href="/console/ship/" target="_blank" class="btn-reg btn-nr f-line f-min">出貨小幫手</a>\
            </li>\
            <li>\
              <a href="/console/fans/" target="_blank" class="btn-reg btn-nr f-line f-min">粉絲小幫手</a>\
            </li>\
          </ul><!--owner_head-tool end-->\
        </nav>\
        <div class="account float-r align-r">\
          <div class="store-name theme ellipsis" style="font-size: 150%; font-weight: bold; padding-right: 8 px ;">張聚洋 </div>\
          <div>張聚洋 您好（ <a href="/console/setting/">設定</a> / <span id="fb" style="cursor: pointer; color: #e75280;">切換帳號</span> ）\
          </div>\
        </div>\
      </div>';

document.write(header);