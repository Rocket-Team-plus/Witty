from django.shortcuts import render
# trips/views.py
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
from datetime import datetime
from django.http import JsonResponse
from trips.models import Products
from trips.models import Streamings
from trips.models import Orders
from trips.models import StreamingsDetail

from django.db.models import Count
from django.db.models import *

from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse

from .forms import DateForm

def hello_world(request):

    if request.method == "POST" and request.is_ajax():
        form = ContactForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            form.save()
            print("bad as ass")
            return JsonResponse({"name": name}, status=200)
        else:
            errors = form.errors.as_json()
            return JsonResponse({"errors": errors}, status=400)

    return render(request, 'hello_world.html', {
        'current_time': str(datetime.now()),
    })

def test_polling(request):
    print(request)

    print('good')
    return render(request, 'hello_world.html', {
        'current_time': str(datetime.now()),
    })

def get_data(request):
    products=Products.objects.all()

    response=[]

    for product in products:
        response_json=dict(name=product.product_name)
        response.append(response_json)

    if request.is_ajax():
        print("good")
        print(request.method)
        print(response)

    return JsonResponse(response, safe=False)

def get_index(request):
    streamings = Streamings.objects.all()

    response = []

    for streaming in streamings:
        response_json = dict(id=streaming.streaming_id,name=streaming.streaming_name)
        response.append(response_json)

    if request.is_ajax():
        print(response)

    return JsonResponse(response, safe=False)

#回傳單場直播的商品狀態
def get_index_product(request):
    # 前端回傳數值
    index=request.POST.get('time')
    response=[]

    #去抓 Product 的 sold_quantity
    products=Products.objects.filter(streaming=index)
    for product in products:
        response_json=dict(product_name=product.product_name,amount=product.quantity_sold)
        response.append(response_json)

    print(response)

    return JsonResponse(response, safe=False)

#回傳單場直播的單據數量狀況
def get_index_order(request):
    # 前端回傳數值
    index=request.POST.get('streaming')
    response=[]

    #time_record 下的每張單據 ????? 相同 time_record 下的單據總數
    orders=Orders.objects.filter(streaming=index).values("time_record").annotate(amount=Count("time_record")).order_by("time_record")

    for order in orders:
        print(order)
        response_json=dict(name=order["time_record"],amount=order["amount"])
        response.append(response_json)

    print(response)

    return JsonResponse(response, safe=False)

#回傳長期時段下每場直播的單據數量表現
def get_index_chronic_order(request):
    # 前端回傳數值
    begin_time=request.POST.get('begin_time')
    end_time=request.POST.get('end_time')

    response=[]

    #每場直播的單據總數
    orders=StreamingsDetail.objects.all().select_related('streaming').filter(time_record__range=(begin_time,end_time)).order_by("streaming")

    for order in orders:
        print(order)
        response_json=dict(streaming_name=order.streaming.streaming_name,
                           time_record=order.time_record,
                           order_amount=order.order_amount)
        response.append(response_json)

    print(response)

    return JsonResponse(response, safe=False)

#回傳單場直播的顧客配送比例表現
def get_index_delivery(request):
    # 前端回傳數值
    index=request.POST.get('time')
    response=[]

    orders_num = Orders.objects.filter(streaming=index).count()
    orders=Orders.objects.select_related('streaming').filter(streaming=index).values("shipping_term").annotate(amount=Count("shipping_term"))

    for order in orders:
        dilivery = order["amount"] / orders_num
        response_json=dict(shipping_term=order["shipping_term"],
                           amount=dilivery)
        response.append(response_json)

    print(response)

    return JsonResponse(response, safe=False)

#回傳單場直播的顧客付款比例表現
def get_index_payment(request):
    # 前端回傳數值
    index=request.POST.get('time')
    response=[]

    orders_num = Orders.objects.filter(streaming=index).count()
    orders=Orders.objects.select_related('streaming').filter(streaming=index).values("payment_term").annotate(amount=Count("payment_term"))
    for order in orders:
        payment = order["amount"] / orders_num
        response_json=dict(payment_term=order["payment_term"],
                           amount=payment)
        response.append(response_json)

    print(response)

    return JsonResponse(response, safe=False)

#回傳單場直播的棄單比例表現
def get_index_droporder(request):
    # 前端回傳數值
    index=request.POST.get('time')
    response=[]

    orders_num=Orders.objects.filter(streaming=index).count()
    orders=Orders.objects.select_related('streaming').filter(streaming=index).values("status").annotate(amount=Count("status"))

    for order in orders:
        droporder=order["amount"]/orders_num
        response_json=dict(status=order["status"],
                           amount=droporder)
        response.append(response_json)


    print(response)

    return JsonResponse(response, safe=False)

#要來做每場直播都可以有 href 連接到更精準狀態
def get_stream_data(request):
    #回傳response
    response=[]

    #用FK做1to1的Left Join Relationship
    stream_datas=StreamingsDetail.objects.all().select_related('streaming')
    
    for stream_data in stream_datas:
        print(stream_data)
        response_json = dict(streaming_name=stream_data.streaming.streaming_name,
                             streaming_time=stream_data.time_record,
                             streaming_like=stream_data.streaming.likes,
                             streaming_comment=stream_data.streaming.comments,
                             streaming_share=stream_data.streaming.shares,
                             streaming_views=stream_data.views,
                             streaming_orders=stream_data.order_amount)
        response.append(response_json)

    return JsonResponse(response, safe=False)

def post_comment(request):

    print(request)
    # 前端回傳數值
    comment=request.POST.get("comment")
    response=[]

    response_json=dict(comment=comment)
    response.append(response_json)

    return JsonResponse(response, safe=False, status=200)

#根據時間區段取得數場直播的貼文數據表現
def get_index_chronic_performance(request):
    #前端回傳數值
    begin_time=request.POST.get('begin_time')
    end_time=request.POST.get('end_time')
    reference_index=request.POST.get('bank_index')
    # 回傳response
    response = []
    print(reference_index)

    # 用FK做1to1的Left Join Relationship
    stream_datas = StreamingsDetail.objects.all().select_related('streaming').filter(time_record__range=(begin_time,end_time))

    #初始化要存進資料的array
    streaming_names=[]
    streaming_times=[]
    streaming_likes=[]
    streaming_comments=[]
    streaming_shares=[]
    streaming_order_amounts=[]
    streaming_views=[]

    #將資料取出放進每個array
    for stream_data in stream_datas:
        streaming_names.append(stream_data.streaming.streaming_name)
        streaming_times.append(stream_data.time_record)
        streaming_likes.append(stream_data.streaming.likes)
        streaming_comments.append(stream_data.streaming.comments)
        streaming_shares.append(stream_data.streaming.shares)
        streaming_order_amounts.append(stream_data.order_amount)
        streaming_views.append(stream_data.views)

    #丟進response array
    response.append(streaming_names)
    response.append(streaming_times)
    response.append(streaming_likes)
    response.append(streaming_comments)
    response.append(streaming_shares)
    response.append(streaming_order_amounts)
    response.append(streaming_views)
    print(response)

    return JsonResponse(response, safe=False)

#根據時間區段取得數場直播的配送分布比例
def get_index_chronic_delivery(request):
    #前端回傳數值
    begin_time=request.POST.get('begin_time')
    end_time=request.POST.get('end_time')

    #先把該時段的每一個直播場次挑出來，找出每場直播的配送分布比例，放進三維陣列，回傳此三維陣列
    #將資料型態改成 [{'streaming_name':'丟丟妹','shipping_proportion':[{'shipping_term':'包裹', 'amount': 0.2},{...},..]},{...}]
    #[{'streaming_name': '丟丟妹',
    #  'shipping_distribution': [{'shipping_term': '包裹', 'amount': 1}]},
    # {'streaming_name': '丟丟妹第二場直播',
    #  'shipping_distribution': [{'shipping_term': '包裹', 'amount': 166},{'shipping_term': '商店取貨', 'amount': 1}]},
    # {'streaming_name': '',
    #  'shipping_distribution': [{}] },
    # {},{},{}.......
    #]
    response=[]
    stream_datas = StreamingsDetail.objects.all().select_related('streaming').filter(time_record__range=(begin_time,end_time))
    for stream_data in stream_datas:
        #建立每場直播資料的array
        one_stream_response=[]
        #取得每場直播id
        stream_id=stream_data.streaming.streaming_id
        stream_name=stream_data.streaming.streaming_name
        record_time=stream_data.time_record
        #計算每場直播的訂單總數
        orders_num=Orders.objects.filter(streaming=stream_id).count()
        # 再根據每場直播的數據，放進一個三維陣列
        orders = Orders.objects.filter(streaming=stream_id).values("shipping_term").annotate(amount=Count("shipping_term"))
        for order in orders:
            shipping_proportion=(order["amount"]/orders_num)
            one_stream_response_json=dict(shipping_term=order["shipping_term"],amount=shipping_proportion)
            one_stream_response.append(one_stream_response_json)
        response_json=dict(streaming_name=stream_name,shipping_distribution=one_stream_response)
        response.append(response_json)

    print(response)

    return JsonResponse(response, safe=False)

#根據時間區段取得數場直播的付款分布比例
def get_index_chronic_payment(request):
    #前端回傳數值
    begin_time=request.POST.get('begin_time')
    end_time=request.POST.get('end_time')

    #先把該時段的每一個直播場次挑出來，找出每場直播的配送分布比例，放進三維陣列，回傳此三維陣列
    #[{'streaming_name': '丟丟妹',
    #  'shipping_distribution': [{'payment_term': '信用卡', 'amount': 122}]},
    # {'streaming_name': '丟丟妹第二場直播',
    #  'shipping_distribution': [{'payment_term': '信用卡', 'amount': 155},{'payment_term': '付現', 'amount': 1}]},
    # {'streaming_name': '',
    #  'shipping_distribution': [{}] },
    # {},{},{}.......
    #]
    response=[]
    stream_datas = StreamingsDetail.objects.all().select_related('streaming').filter(time_record__range=(begin_time,end_time))
    for stream_data in stream_datas:
        #建立每場直播資料的array
        one_stream_response=[]
        #取得每場直播id
        stream_id=stream_data.streaming.streaming_id
        stream_name=stream_data.streaming.streaming_name
        record_time=stream_data.time_record
        # 計算每場直播的訂單總數
        orders_num = Orders.objects.filter(streaming=stream_id).count()
        # 再根據每場直播的數據，放進一個二維陣列
        orders = Orders.objects.filter(streaming=stream_id).values("payment_term").annotate(amount=Count("payment_term"))
        for order in orders:
            payment_proportion=(order["amount"]/orders_num)
            one_stream_response_json=dict(payment_term=order["payment_term"],amount=payment_proportion)
            one_stream_response.append(one_stream_response_json)
        response_json=dict(streaming_name=stream_name,payment_distribution=one_stream_response)
        response.append(response_json)

    print(response)

    return JsonResponse(response, safe=False)

#根據時間區段取得數場直播的單據狀態分布比例
def get_index_chronic_droporder_status(request):
    #前端回傳數值
    begin_time = request.POST.get('begin_time')
    end_time = request.POST.get('end_time')

    #先把該時段的每一個直播場次挑出來，找出每場直播的配送分布比例，放進三維陣列，回傳此三維陣列
    #[{'streaming_name': '丟丟妹',
    #  'shipping_distribution': [{'status': '已付款', 'amount': 122}]},
    # {'streaming_name': '丟丟妹第二場直播',
    #  'shipping_distribution': [{'status': '已付款', 'amount': 155},{'status': '棄單', 'amount': 12}]},
    # {'streaming_name': '',
    #  'shipping_distribution': [{}] },
    # {},{},{}.......
    #]
    response=[]
    stream_datas = StreamingsDetail.objects.all().select_related('streaming').filter(time_record__range=(begin_time,end_time))
    for stream_data in stream_datas:
        #建立每場直播資料的array
        one_stream_response=[]
        #取得每場直播id
        stream_id=stream_data.streaming.streaming_id
        stream_name=stream_data.streaming.streaming_name
        record_time=stream_data.time_record
        # 計算每場直播的訂單總數
        orders_num = Orders.objects.filter(streaming=stream_id).count()
        # 再根據每場直播的數據，放進一個二維陣列
        orders = Orders.objects.filter(streaming=stream_id).values("status").annotate(amount=Count("status"))
        for order in orders:
            droporder_proportion=(order["amount"]/orders_num)
            one_stream_response_json=dict(status=order["status"],amount=droporder_proportion)
            one_stream_response.append(one_stream_response_json)
        response_json=dict(streaming_name=stream_name,status_distribution=one_stream_response)
        response.append(response_json)

    print(response)

    return JsonResponse(response, safe=False)

@csrf_exempt                    #對此試圖函式新增csrf裝飾器，使得此函式的post請求免驗證tooken
def chatbot_message(request):
    """
    收到客戶端傳送過來的資產資訊
    :param request:
    :return:
    """

    info = json.loads(request.body.decode('utf-8'))
    """
    b'{"comment":"留言內容"}'
    #傳輸的資料為編碼後的json 格式需要先解碼，在轉化後才能當作字典來使用
    """

    #把info傳到 analysis 頁面上

    return HttpResponse("收到了")